@echo off
chcp 65001 >nul
cd /d "%~dp0"
where pythonw >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    start "" pythonw "%~dp0python\main.py"
) else (
    start "" "%~dp0KharratCode.exe"
)
